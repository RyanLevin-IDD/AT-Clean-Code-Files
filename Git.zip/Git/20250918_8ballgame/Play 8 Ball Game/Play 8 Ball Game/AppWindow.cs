using System;
using System.Windows.Forms;
using Microsoft.Web.WebView2.WinForms;
namespace Shoot_8_Ball
{
    public partial class AppWindow : Form
    {
        private WebView2 webView;

        public AppWindow()
        {
            InitializeComponent();
            this.MaximizeBox = false;
            InitializeWebView();
        }

        private async void InitializeWebView()
        {
            try
            {
                webView = new WebView2
                {
                    Dock = DockStyle.Fill
                };
                this.Controls.Add(webView);

                string userSpecificFolder = System.IO.Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                    "Play_8_Ball_Game_WebView2",
                    Environment.UserName
                );

                var env = await Microsoft.Web.WebView2.Core.CoreWebView2Environment.CreateAsync(userDataFolder: userSpecificFolder);
                await webView.EnsureCoreWebView2Async(env);

                webView.CoreWebView2.SetVirtualHostNameToFolderMapping(
                    "app.local",
                    AppDomain.CurrentDomain.BaseDirectory,
                    Microsoft.Web.WebView2.Core.CoreWebView2HostResourceAccessKind.Allow);

                webView.Source = new Uri("https://app.local/index.html");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error initializing WebView2: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void Form1_Load(object sender, EventArgs e) { }

        private void AppWindow_Load(object sender, EventArgs e)
        {

        }
    }
}
