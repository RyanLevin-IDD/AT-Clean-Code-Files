using System;
using System.Windows.Forms;
using Microsoft.Web.WebView2.WinForms;
namespace Sudoku_Game
{
    public partial class AppWindow : Form
    {
        // Instance of the WebView2 control
        private WebView2 webView;
        // Initializes a new instance of Form.
        public AppWindow()
        {
            InitializeComponent();
            this.MaximizeBox = false;
            InitializeWebView();
        }
        // Asynchronously initializes the WebView2 control, setting up its environment and loading the default URL.
        private async void InitializeWebView()
        {
            try
            {
                // Create a new WebView2 instance and dock it to fill the form
                webView = new WebView2
                {
                    Dock = DockStyle.Fill
                };
                // Add the WebView2 to the Controls collection
                this.Controls.Add(webView);
                // Define a unique UserDataFolder path for the current user
                string userSpecificFolder = System.IO.Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                    "Sudoku_Game_WebView2",
                    Environment.UserName
                );
                // Create a WebView2 environment using the unique folder
                var env = await Microsoft.Web.WebView2.Core.CoreWebView2Environment.CreateAsync(userDataFolder: userSpecificFolder);
                await webView.EnsureCoreWebView2Async(env);
                // Get the full path of the local HTML file
                string localFilePath = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "index.html");
                if (System.IO.File.Exists(localFilePath))
                {
                    // Convert the path to a valid file URL
                    string fileUri = new Uri(localFilePath).AbsoluteUri;
                    webView.Source = new Uri(fileUri);
                }
                else
                {
                    MessageBox.Show("File not found: " + localFilePath, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error initializing WebView2: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
